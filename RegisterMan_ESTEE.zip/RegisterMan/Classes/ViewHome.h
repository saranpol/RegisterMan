//
//  ViewHome.h
//  RegisterMan
//
//  Created by saranpol on 9/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ViewHome : UIViewController {

}

- (IBAction)clickHomeButton:(id)sender;

@end
